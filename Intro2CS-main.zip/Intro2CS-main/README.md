# Intro to Computer Sceince - Ariel University
This is an educational repository for teaching introduction to Computer Science in java (Ariel University) This repository contains documants and code examples for the CS-101 course. This course is designed to teach Computer Science Students the basic components of computer science using Java. The course requires absolutely no background in programming. At the end of the course students should gain a good programming skills as well as theorecical anderstanding, in particular: sorting, functions, recursion, text files, classes and interfaces.

Code standards: Java: https://google.github.io/styleguide/javaguide.html#s2.1-file-name 
