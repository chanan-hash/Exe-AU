package week4;

public class Test_gcd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=34,b=55;
		
		// Math.sqrt();
		int g = GCD4.gcd2(a, b);
		System.out.println(g);
		double d = Math.log10(g);
	}

}
