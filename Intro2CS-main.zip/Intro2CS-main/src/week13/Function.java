package week13;

public interface Function {
	public double f(double x);
}
