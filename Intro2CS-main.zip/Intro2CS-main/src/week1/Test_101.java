package week1;

public class Test_101 {
	public static void main(String[] args) {
		double i = 3;
		i = i *5.3;
		System.out.println("Hello World!");
		String msg = "this is a nice String ";
		System.out.println(msg + i);
	}

}
