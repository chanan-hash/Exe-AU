package Exe.EX3;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyMap2DTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
