package Exe.Ex2;

import java.util.Arrays;

public class Ex2_check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "-2x-2";
		double[] point = getPolynomFromString(s);
		System.out.println(Arrays.toString(point));
		System.out.println(Arrays.toString(Ex2.getPolynomFromString("x-2")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("2x-2")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("-2")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("2")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("-2x-2")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("-x^2+x-2")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("8x^10-3x^2-x+2")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("0")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("x^4+x^3+x^2+x")));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("-4.5x^4-x^3-x^2-x")));
        System.out.println(Ex2.getPolynomFromString(""));
        System.out.println(Arrays.toString(Ex2.getPolynomFromString("-4.5x^4-x^2-2x^3-x")));
        double[] pol = {16,10,1};
        System.out.println(Ex2.root(pol,-10 , 10, Ex2.EPS));
        System.out.println(Ex2.root(pol,-10 , -6, Ex2.EPS));
        
        //16.60974246171407
        double[] po11 = {2,1,-0.7, -0.02,0.02};
		double[] po22 = {-3, 0.61, 0.2};
		double[] po1 = {0,3};
		double[] po2 = {0,0,1};
		double area = Ex2.area(po11,po22, 0, 10, 13);
        System.out.println(area);
		double area2 = Ex2.area(po1,po2, 0, 3, 13);
	    System.out.println(area2);
		
	
	}

	public static double[] getPolynomFromString(String p) {
		p = p.replaceAll("-", "+-");
		if (p.startsWith("+-")) {
			p = p.substring(1);
		}
		String[] parts = p.split("\\+");
		int deg;

		if (parts[0].contains("x")) {
			if (parts[0].contains("^")) {
				deg = Integer.parseInt(parts[0].split("\\^")[1]);
			} else {
				deg = 1;
			}
		} else {
			return new double[]{Double.parseDouble(parts[0])};
		}

		double[] pol = new double[deg + 1];

		for (String part : parts) {
			if (part.isBlank()) continue;

			if (part.contains("x")) {
				if (part.contains("^")) {
					deg = Integer.parseInt(part.split("\\^")[1]);
				} else {
					deg = 1;
				}
			} else {
				deg = 0;
			}
			if (part.startsWith("x")) {
				pol[deg] = 1;
			} else if (part.startsWith("-x")) {
				pol[deg] = -1;
			} else {
				pol[deg] = Double.parseDouble(part.split("x")[0]);
			}
		}

		return pol;
	}

	public static boolean equals(double[] p1, double[] p2) {
		boolean ans = true;
		// *** add your code here ***
		if(p1.length != p2.length) { // means that they aren't equal
			ans = false;
			return ans;
		}

		for(int i = 0; i<p1.length; i++) {
			// we want the loop to run equaly and not nested loop so 'j' ned to bee <= 'i'
			if(p1[i] != p2[1] ) { // already here we can that they are not eqaul
				ans = false; 
				return ans;
			}

		}
		return ans;
	}

	//finished
	public static double[] add(double[] p1, double[] p2) {
		// *** add your code here ***
		double [] longArray;
		double [] shortArray;

		if ((p1.length==0)|| (p2.length == 0)) {
			longArray = null;
		}

		if (p1.length>p2.length) {
			longArray = Arrays.copyOf(p1, p1.length); // copy of the array. 
			shortArray = Arrays.copyOf(p2, p2.length); 
		}
		else {
			longArray = Arrays.copyOf(p2, p2.length); // copy of the array. 
			shortArray = Arrays.copyOf(p1, p1.length); 		
		}

		for (int i = 0; i<shortArray.length;i++) {
			longArray[i] = longArray[i] + shortArray[i];
		}
		return longArray; //return p1;
		// **************************
	}

	//finished
	public static double[] mul(double[] p1, double[] p2) {
		// *** add your code here ***
		double [] mulArray = new double [p1.length + p2.length -1]; // because the exponent is growing

		for (int i = 0; i < p1.length; i++) {
			for (int j = 0; j < p2.length; j++) {
				mulArray[i + j] += p1[i] * p2[j];
			}
		}
		return mulArray; 

	}

	// finished
	public static double f(double[] poly, double x) {
		double ans = 0;
		// *** add your code here ***
		for (int i = 1; i<poly.length; i++) {
			ans = ans +(poly[i]*(Math.pow(x, i))); // we are taking the value in place i, multiply by the given 'x' pwoer the index
		}
		ans += poly[0];
		// **************************
		return ans;
	}

	// finished
	public static double[] derivative (double[] po) {
		// *** add your code here ***
		double[]derv = new double [po.length];
		for (int i = po.length-1 ; i>0; i--) {
			derv[i] = po[i]*i; // x^2 --> 2x
		}
		double[] finalDerv = new double [derv.length-1];
		for (int i = 0; i<derv.length-1; i++) {
			finalDerv [i] = derv[i+1]; //taking down the coefficient that equal to zero
		}
		return finalDerv;
		// **************************
	}


	// finished
	public static String poly(double[] poly) {
		String ans = "";
		if (poly.length == 0) {
			ans = null;
			return ans;
		}

		if(poly.length == 1) {
			return poly[0]+""; // making it to String
		}
		for (int i = poly.length-1; i > 0; i--) {

			if (poly[i] != 0) { // if the coefficient is not Zero
				ans += (poly[i]>0?"+" : "") + String.valueOf(poly[i])+  "x" + (i>1 ? "^": "") + String.valueOf(i);
			}
		}
		ans += poly[0]!=0 ? ((poly[0]>0? "+" : "") + String.valueOf(poly[0])) :"";

		ans = ans.replace("x1","x");

		if(ans.charAt(0)== '+') { //removing the plus at the beginning, if exists
			return ans.substring(1);
		}
		return ans;

	}




	//	public static double[] getPolynomFromString(String p) {
	//		p=p.strip();
	//		String s= p.replaceAll("-", "+-"); 	//we want to split according to '+'
	//		if(s.startsWith("+-")) {
	//			s = s.substring(1);
	//		}
	//	//	System.out.println(s);
	//		String [] parts = s.split("\\+");
	//		//System.out.println(Arrays.toString(parts));
	//		int deg=0; 							//getting the degree for the length of the polynomial array
	//
	//		if (parts[0].contains("x")) {
	//			if(parts[0].contains("^")){
	//				String temp = parts[0].split("\\^")[1].strip(); // taking of all the things around the number	
	//			//	System.out.println(temp);
	//																//[1] --> means we want the place before the '^'
	//				deg = Integer.parseInt(temp); 
	//			}
	//			else {
	//				deg = Integer.parseInt(parts[0].split("x")[0]); //the first 'x', the degree is One
	//			}
	//		}
	//
	//		else {
	//			// Dealing the case which the String has only One number exmp: "2" or "-1" ("-1" is to characters, '-' & '1') 
	//			if(parts.length < 2 ) {
	//				return new double[] {Double.parseDouble(parts[0])}; 
	//			}
	//			else {
	//				return new double[] {Double.parseDouble(parts[1])};
	//					}
	//				
	//				//				return new double[] {Double.parseDouble(str2[1].split("x"))*-1}; 	
	//			
	//		}
	//
	//		// Finding the coefficient themselves 
	//		double [] pol = new double [deg+1];
	//		for(String part : parts ) {			// 'parts' is the split array according to '+'
	//			if (part.isBlank()) {
	//				continue;
	//			}
	//			if (part.contains("x")) {
	//				if(part.contains("^")){
	//					String temp = part.split("\\^")[1].strip();
	//					deg = Integer.parseInt(temp);
	//				}
	//
	//				else {
	//					deg=1;
	//				}
	//			}
	//
	//			else {
	//				deg = 0;
	//			}
	//			String temp = part.split("x")[0].strip();
	//			part.replaceAll("x|-x", "1|-1");
	//			pol[deg] = Double.parseDouble(temp);
	//		}
	//		return pol;
	//	}
	//
}
